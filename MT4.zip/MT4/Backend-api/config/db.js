//database Connection String
module.exports={
    DB:"mongodb://localhost:27017/products"
}