const express=require('express');
const app=express();
const bodyParser=require('body-parser');
const cors=require('cors');
const mongoose=require('mongoose');
const config=require('./config/db');
const productRoutes=require('./routes/productRoutes');
const PORT=4000;



mongoose.Promise=global.Promise;
app.use(cors());
app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());

//connecting mongoDB
mongoose.connect(config.DB,{useNewUrlParser:true})
.then(()=>{
    console.log("Mongo DB database connection established successfully on port "+PORT),
    err=>{console.log('Cannot connect to database'+err.stack)}
});

//Setting routes
app.use('/products',productRoutes);

//listening port
app.listen(PORT,function(){
    console.log("Server is running on port :"+PORT)
})