import React from 'react';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';
import Login from './components/login.component';
import Home from './components/home.component';
import ProductsList from './components/products-list.component';
import CreateProduct from './components/create-product.component';
import Clock from './components/clock.component';
import { Icon } from 'semantic-ui-react';
function App() {
  return (
    <Router>
      <div className="container">
        <nav className="navbar navbar-expand-lg navbar-light bg-info">
          <a className="navbar-brand" href="http://google.com"
            rel="noopener noreferer" target="_blank">
            <img src="images/image1.png" width="30" height="40" />
          </a>
          {/*Routes*/}
          <Link to='/' className="navbar-brand text-light">Virtual Cooking</Link>
          <button className="navbar-toggler" type="button" data-toggle="collapse"
            data-target="#collapsibleNavbar">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="collapsibleNavbar">
            <ul className="navbar-nav mr-auto">
              <Icon className="home" size="big"></Icon>
              <li className="navbar-item">

                <Link to='/home' className="nav-link text-light">Home</Link>
              </li>
              <Icon className="book" size="big"></Icon>
              <li className="navbar-item">
                <Link to='/about' className="nav-link text-light">About</Link>
              </li>
              <Icon className="phone" size="big"></Icon>
              <li className="navbar-item">
                <Link to='/contact' className="nav-link text-light">Contact</Link>
              </li>
              <Icon className="envira gallery" size="big"></Icon>
              <li className="navbar-item">
                <Link to='/gallery' className="nav-link text-light">Gallery</Link>
              </li>
              <Icon className="product hunt " size="big"></Icon>
              <li className="navbar-item">
                <Link to='/products' className="nav-link text-light">View Products</Link>
              </li>

            </ul>
            <ul className="navbar-nav ml-auto">
              <li className="navbar-item">
                <Link to='/login' className="nav-link text-light">Login</Link>
              </li>
            </ul>
          </div>
        </nav>
        <br />
        <Route path='/' exact component={Home} />
        <Route path='/home' component={Home} />
        <Route path='/products' component={ProductsList} />
        <Route path='/login' component={Login} />


        <hr />
        <Clock />
        <a href="http://facebook.com" target="_blank">
          <span className="text-primary">
            <i className="fa fa-facebook-square" style={{ fontSize: 45 }}></i>
          </span>
        </a>&nbsp;
        <a href="http://twitter.com" target="_blank">
          <span className="text-info">
            <i className="fa fa-twitter" style={{ fontSize: 45 }}></i>
          </span>
        </a>&nbsp;
        <a href="http://google.com" target="_blank">
          <span className="text-danger">
            <i className="fa fa-google-plus-official" style={{ fontSize: 45 }}></i>
          </span>
        </a>&nbsp;
        <a href="http://whatsapp.com" target="_blank">
          <span className="text-info">
            <i className="fa fa-whatsapp" style={{ fontSize: 45 }}></i>
          </span>
        </a>
      </div>

    </Router>
  );
}

export default App;
