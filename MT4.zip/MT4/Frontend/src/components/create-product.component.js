import React,{Component} from 'react';
import axios from 'axios';
import Button from 'reactstrap/lib/Button';


class CreateProduct extends Component{
    constructor(props){
        super(props);
        this.onChangeProductName=this.onChangeProductName.bind(this);
        this.onChangeProductCost=this.onChangeProductCost.bind(this);
        this.onSubmit = this.onSubmit.bind(this);
        this.clearForm = this.clearForm.bind(this);
        this.state={
            product_name:'',
            product_cost:'',
           
        }
    }
        onChangeProductName(e){
            this.setState({
                product_name:e.target.value
            })
        }
        onChangeProductCost(e){
        this.setState({
            product_cost:e.target.value
        })
    }

    onSubmit(e){
        e.preventDefault();
        const newProduct={
            product_name:this.state.product_name,
            product_cost:this.state.product_cost,
        };

        axios.post('http://localhost:4000/products/add',newProduct)
        .then(res=>console.log(res.data));
        this.setState({
            product_name:'',
            product_cost:'',
        })
        window.location.reload();
    }
    clearForm(e){
        e.preventDefault();
        this.setState({
            product_name: '',
            product_cost: '',
         })
    }
    render(){
        return(
            <div className="col-lg-7">
            
            <h3>Manage Products</h3>
          
                <form onSubmit={this.onSubmit}>
                <div>
                    <label>Product name:</label>
                    <input type="text" className="form-control"value={this.state.product_name}
                     onChange={this.onChangeProductName} />
                      <label>Product Cost:</label>
                    <input type="number" className="form-control" required value={this.state.product_cost}
                        onChange={this.onChangeProductCost} /><br />
                    <Button type="submit" outline color="success">Add Product</Button>  &nbsp;
                    <Button outline color="danger" onClick={this.clearForm}>Clear</Button>
                    {/* <button type="submit" className="btn btn-success"> Add Product</button>&nbsp; */}
                
                </div>
                
            </form>
           
            </div>
        )
    }
}

export default CreateProduct;