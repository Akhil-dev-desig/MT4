import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import { Badge } from 'reactstrap';

import swal from 'sweetalert';
import axios from 'axios'
import CreateProduct from './create-product.component';

class Product extends Component {
    constructor(props) {
        super(props);
        this.deleteProduct = this.deleteProduct.bind(this);
    }
    deleteProduct() {
        let result = window.confirm('Are You Sure You Want To delete Product')
            
        if (result) {
            axios.get('http://localhost:4000/products/delete/' + this.props.product._id)
                .then(console.log('Product Deleted Successfully'))
                .catch(err => console.log(err));
        }
        window.location.reload();
    }
    render() {
        return (
            <tr>
                <td>{this.props.product.product_name}</td>
                <td>{this.props.product.product_cost}</td>
                <td>
                    <button onClick={this.deleteProduct} className="btn btn-link">Delete</button>
                </td>
            </tr>
        )
    }
}

class ProductsList extends Component {
    constructor(props) {
        super(props);
        this.state = { products: [], id: '' };
        this.componentDidMount();
    }

    componentDidMount() {
        axios.get('http://localhost:4000/products/')
            .then(response => {
                console.log(response.data);
                this.setState({ products: response.data })
            })
            .catch(function (error) {
                console.log(error)

            })
    }
//code for displaying products list
    productsList() {
        return this.state.products.map(function (currentProduct, i) {
            return <Product product={currentProduct} key={i} />
        })
    }
    render() {
        return (
            <div className="container">
            <div className="offset-lg-4 col-lg-7">
                    <CreateProduct />
                </div>
                <br/>
                <br/>
                <div className="offset-lg-4 col-lg-7">
                    <h2>Total No Of Products <Badge color="info"> {this.state.products.length}</Badge></h2>

                    <table className="table table-striped" style={{ marginTop: 20 }}>
                        <thead>
                            <tr>
                                <th>Product Name</th>
                                <th>Product Cost</th>
                                <th colSpan="2">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {this.productsList()}
                        </tbody>
                    </table>
                </div>
                
            </div>

        )
    }
}

export default ProductsList;