import React,{Component} from 'react';

export default class Clock extends Component{
    constructor(){
        super();
        this.launchClock()
        this.state={
            currentTime:(new Date()).toLocaleString()
        }
        console.log(this.state)
    }
    launchClock(){
        setInterval(()=>{
            console.log('Updating Time..');
            this.setState({
                currentTime:(new Date()).toLocaleString()
            })
        },1000)
    }
    render(){
        return(
            <div className="offset-lg-6 col-lg-4">
                <h4 className="text-info">{this.state.currentTime}</h4>
                </div>
        );
    }
}