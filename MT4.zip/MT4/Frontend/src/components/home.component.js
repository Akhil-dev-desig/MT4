import React, { Component } from 'react';


export default class Home extends Component {
    constructor(props) {
        super(props);
    }
    render() {
        return (
            <div className="container">
                <div className="row">
                    <div className="offset-lg-2 col-lg-8">
                        <h1 className="text-success text-center">Welcome To Online Shopping Page</h1>
                        <hr />
                        <img src="images/source.gif" width="100%" />
                    </div>
                </div>
            </div>
        )
    }
}