import React, { Component } from 'react';
import axios from 'axios';
import swal from 'sweetalert';
class Login extends Component {
    constructor() {
        super();

        //Binding text box event
        this.state = {
            fields: {
                user_email: '',
                user_password: ''
            },
            errors: {},
            formIsValid: true
        }
        this.handleChange = this.handleChange.bind(this);
        this.submitLoginForm = this.submitLoginForm.bind(this);
    }//end of the constructor
    handleChange(e) {
        let fields = this.state.fields;
        fields[e.target.name] = e.target.value;
        this.setState({
            fields: fields
        });
        console.log(this.state.fields);
    }
    submitLoginForm(e) {
        e.preventDefault();
        if (this.validateForm()) {
            if (this.state.fields.user_email === "admin@gmail.com" && this.state.fields.user_password === "123456") {
                let fields = {};
                fields["user_email"] = '';
                fields["user_password"] = '';
                this.setState({ fields: fields });
                swal({
                    title: "Good job!",
                    text: "Login Successfully!",
                    icon: "success",
                    button: "ok",
                  });
                this.props.history.push('/products');
            } else {
                alert("Invalid Username or Password")

            }
        }
    }//end of the submit button

    validateForm() {
        let fields=this.state.fields;
        let errors={};
        let formIsValid=true;

        if(!fields["user_email"]){
            formIsValid=false;
            errors["user_email"]="Please Enter Your Email Id.";
        }
        else if(typeof fields.user_email!=="undefined"){
            if(!fields.user_email.match(/^([\w.%+-]+)@([\w-]+\.)+([\w]{2,})$/i)){
                formIsValid=false;
                errors.user_email="Please Enter Valid Email Id."
            }
        }
        else {
            errors.user_email="";
            
        }
        if(!fields["user_password"]){
            formIsValid=false;
            errors.user_password="Please Enter Your Password.";
        }
        else if(typeof fields.user_password!=="undefined"){
            if(!fields.user_password.length>=3){
                formIsValid=false;
                errors.user_password="Password is too short."
            }
        }
        else {
            errors.user_password="";
            
        }
        this.setState({
            errors:errors,
            formIsValid:formIsValid
        });
        return formIsValid;
    }
    render() {
        return (
            <div className="container">
               
                <div className=" offset-lg-3 col-lg-6">
                <h2>Login</h2>
                <form method="post" name="loginForm" onSubmit={this.submitLoginForm}>
                    
                        <div className="form-group">
                            <label>Email ID:</label>
                            <input type="text" name="user_email" className="form-control" value={this.state.fields.user_email}
                                onChange={this.handleChange} />
                            <div className={this.state.errors.user_email ? 'alert alert-danger' : ''}>
                                {this.state.errors.user_email}
                            </div>
                        </div>
                        <div className="form-group">
                            <label>Password:</label>
                            <input type="password" className="form-control" name="user_password" value={this.state.fields.user_password}
                                onChange={this.handleChange} />
                                <div className={this.state.errors.user_password ? 'alert alert-danger' : ''}>
                                {this.state.errors.user_password}
                            </div>
                        </div>
                        <div className="form-group">
                        <input type="submit" className="btn btn-success" value="Login"/>
                         {/* disabled={!this.state.formIsValid} */}
                        </div>
                    
                </form>
                </div>


            </div>
        );
    }
}
export default Login;